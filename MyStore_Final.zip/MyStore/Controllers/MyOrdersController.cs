﻿
using System.Linq;
using System.Web.Mvc;
using MyStore.Models;

namespace MyStore.Controllers
{
    public class MyOrdersController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        public ActionResult Index(string status, string keyword, bool xemThem = false)
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Account");

            string username = Session["Username"].ToString();

            var orders = db.Orders
                .Where(o => o.Customer.Username == username);

            if (!string.IsNullOrEmpty(keyword))
            {
                int id;
                if (int.TryParse(keyword, out id))
                    orders = orders.Where(o => o.OrderID == id);
                else
                    orders = orders.Where(o =>
                        o.OrderDetails.Any(d =>
                            d.Product.ProductName.Contains(keyword)));
            }

            if (!string.IsNullOrEmpty(status))
            {
                if (status == "Chờ thanh toán")
                    orders = orders.Where(o => o.PaymentStatus == "Pending");
                else if (status == "Đang vận chuyển")
                    orders = orders.Where(o => o.PaymentStatus == "Đang giao");
                else
                    orders = orders.Where(o => o.PaymentStatus == status);
            }

            ViewBag.Status = status;
            ViewBag.Keyword = keyword;
            ViewBag.XemThem = xemThem;

            return View(orders
                .OrderByDescending(o => o.OrderDate)
                .Take(50)
                .ToList());
        }

        public ActionResult Details(int id)
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Account");

            string username = Session["Username"].ToString();

            var order = db.Orders.FirstOrDefault(o =>
                o.OrderID == id &&
                o.Customer.Username == username);

            if (order == null)
                return HttpNotFound();

            return View(order);
        }

        public ActionResult BuyAgain(int id)
        {
            if (Session["Username"] == null)
                return RedirectToAction("Login", "Account");

            string username = Session["Username"].ToString();

            var order = db.Orders.FirstOrDefault(o =>
                o.OrderID == id &&
                o.Customer.Username == username);

            if (order == null)
                return HttpNotFound();

            var cart = Session["Cart"] as
                System.Collections.Generic.List<CartItem>;

            if (cart == null)
                cart = new System.Collections.Generic.List<CartItem>();

            foreach (var detail in order.OrderDetails)
            {
                var product = db.Products.Find(detail.ProductID);

                if (product != null)
                    cart.Add(new CartItem { Product = product, Quantity = 1 });
            }

            Session["Cart"] = cart;
            return RedirectToAction("Cart", "Store");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
