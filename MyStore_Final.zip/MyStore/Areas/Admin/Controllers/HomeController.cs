﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyStore.Areas.Admin.Controllers
{
    public class HomeController : Controller
    {
        // GET: Admin/Home
        public ActionResult Index()
        {
            if (Session["UserRole"] == null ||
                Session["UserRole"].ToString() != "A")
            {
                return RedirectToAction("Login", "Account",
                    new { area = "" });
            }

            return View();
        }
    }
}